﻿// This script runs when the "Web Guardian" popup is opened.

document.addEventListener('DOMContentLoaded', () => {

    // Get the HTML elements we need from the new popup.html
    const statusTextElement = document.getElementById('status-text');
    const domainTextElement = document.getElementById('domain-text'); // <-- NEW: Get the domain element

    // Ask Chrome for information about the currently active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentTab = tabs[0];

        // Handle cases where we can't get a valid URL
        if (!currentTab || !currentTab.url || currentTab.url.startsWith('chrome://')) {
            statusTextElement.textContent = "Cannot access browser pages.";
            domainTextElement.textContent = "N/A";
            statusTextElement.style.color = "orange";
            return;
        }

        const tabUrl = currentTab.url;

        // Load our site lists from the JSON file
        fetch('site_lists.json')
            .then(response => response.json())
            .then(siteLists => {

                // --- Logic to check the domain ---

                // Normalize the domain name
                const domain = new URL(tabUrl).hostname.replace(/^www\./, '');

                // NEW: Display the normalized domain in the popup
                domainTextElement.textContent = domain;

                const isSiteMalicious = siteLists.malicious_sites.includes(domain);
                const isSiteSafe = siteLists.safe_sites.includes(domain);

                // --- Update the status display based on the result ---
                if (isSiteMalicious) {
                    statusTextElement.textContent = "WARNING: MALICIOUS SITE";
                    statusTextElement.style.color = "#e74c3c"; // Red
                } else if (isSiteSafe) {
                    statusTextElement.textContent = "VERIFIED SAFE";
                    statusTextElement.style.color = "#2ecc71"; // Green
                } else {
                    statusTextElement.textContent = "UNKNOWN SITE";
                    statusTextElement.style.color = "#f39c12"; // Orange
                }
            })
            .catch(error => {
                console.error("Error loading site_lists.json:", error);
                statusTextElement.textContent = "Error: Could not load lists.";
                statusTextElement.style.color = "red";
            });
    });
});