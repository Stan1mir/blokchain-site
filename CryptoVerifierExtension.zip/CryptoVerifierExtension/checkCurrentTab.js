async function checkCurrentTab(tabId, url) {

    // --- LOG 1: What URL are we starting with? ---
    console.log(`1. Checking URL: ${url}`);

    if (!url || !url.startsWith('http')) {
        chrome.action.setIcon({ path: 'icons/orange.png', tabId: tabId });
        return;
    }

    try {
        const response = await fetch(chrome.runtime.getURL('site_lists.json'));
        if (!response.ok) {
            console.error("CRITICAL: Could not load site_lists.json file!");
            return;
        }
        const siteLists = await response.json();

        // --- LOG 2: Did we load the lists correctly? ---
        console.log('2. Successfully loaded site lists:', siteLists);

        const domain = new URL(url).hostname.replace(/^www\./, '');

        // --- LOG 3: What domain did we calculate? ---
        console.log(`3. Calculated Domain: "${domain}"`);

        const isMalicious = siteLists.malicious_sites.includes(domain);
        const isSafe = siteLists.safe_sites.includes(domain);

        // --- LOG 4: What were the results of the check? ---
        console.log(`4. Is it malicious? ${isMalicious}. Is it safe? ${isSafe}.`);

        let iconPath = 'icons/orange.png';
        if (isMalicious) {
            iconPath = 'icons/red.png';
        } else if (isSafe) {
            iconPath = 'icons/green.png';
        }

        // --- LOG 5: What icon are we setting? ---
        console.log(`5. Setting icon to: ${iconPath}`);

        chrome.action.setIcon({ path: iconPath, tabId: tabId });

    } catch (error) {
        console.error("CRITICAL Error during check:", error);
    }
}
