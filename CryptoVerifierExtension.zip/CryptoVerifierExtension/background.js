﻿// This is the complete, final background script.

// --- The Main Function (The "Engine") ---
// This function does all the work of checking the URL.
async function checkCurrentTab(tabId, url) {

    // 1. Ignore special browser pages that aren't real websites.
    if (!url || !url.startsWith('http')) {
        chrome.action.setIcon({ path: "icons/Unknown.png", tabId: tabId });
        return;
    }

    try {
        // 2. Load our lists of sites from the JSON file.
        const response = await fetch(chrome.runtime.getURL('site_lists.json'));
        if (!response.ok) {
            console.error("Could not load site_lists.json");
            return;
        }
        const siteLists = await response.json();

        // 3. Clean the URL to get just the domain name.
        const domain = new URL(url).hostname.replace(/^www\./, '');

        // 4. Check if the domain is in our lists.
        const isMalicious = siteLists.malicious_sites.includes(domain);
        const isSafe = siteLists.safe_sites.includes(domain);

        // 5. Choose the correct icon based on the result.
        let iconPath = "icons/Unknown.png"; // The default icon
        if (isMalicious) {
            iconPath = "icons/icon-notsafe.png"; // Set to Red
        } else if (isSafe) {
            iconPath = "icons/icon-safe.png"; // Set to Green
        }

        // 6. Apply the chosen icon to the current tab.
        chrome.action.setIcon({ path: iconPath, tabId: tabId });

    } catch (error) {
        console.error("Error during URL check:", error);
    }
}

// --- Event Listeners (The "Ignition Switches") ---
// These tell the script WHEN to run the check.

// 1. When a tab's URL changes.
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url) {
        checkCurrentTab(tabId, changeInfo.url);
    }
});

// 2. When the user switches to a different tab.
chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        if (tab && tab.url) {
            checkCurrentTab(tab.id, tab.url);
        }
    });
});