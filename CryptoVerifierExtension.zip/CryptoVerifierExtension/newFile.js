`);
        }
        return await response.json();
    } catch (error) {
        console.error("Could not load or parse site_lists.json:", error);
        return null; // Return null if there's an error
    }
}

// A single function to check the tab and set the icon
async function checkTabAndSetIcon(tabId, tabUrl) {
    const siteLists = await getSiteLists();

    // Do nothing if we couldn't load our lists
    if (!siteLists) {
        chrome.action.setIcon({ path: "icons/orange.png", tabId: tabId });
        return;
    }

    // Check for valid web page URLs
    if (!tabUrl || !tabUrl.startsWith('http')) {
        chrome.action.setIcon({ path: "icons/orange.png", tabId: tabId });
        return;
    }

    const url = new URL(tabUrl);
    const domain = url.hostname.replace(/^www\./, ''); // Normalize the domain

    // Compare against the lists
    if (siteLists.malicious_sites.includes(domain)) {
        chrome.action.setIcon({ path: "icons/red.png", tabId: tabId });
    } else if (siteLists.safe_sites.includes(domain)) {
        chrome.action.setIcon({ path: "icons/green.png", tabId: tabId });
    } else {
        chrome.action.setIcon({ path: "icons/orange.png", tabId: tabId });
    }
}

// --- Event Listeners ---
// These tell the script WHEN to run the check.

// 1. When a tab is updated (e.g., user navigates to a new page)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // We only need to run this when the URL changes to avoid unnecessary checks
    if (changeInfo.url) {
        checkTabAndSetIcon(tabId, changeInfo.url);
    }
});

// 2. When the user switches to a different tab
chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        if (tab) {
            checkTabAndSetIcon(tab.id, tab.url);
        }
    });
});`;
