﻿// This function runs automatically when the popup is opened.
document.addEventListener('DOMContentLoaded', async () => {
    // Get the HTML elements we want to update.
    const statusTextElement = document.getElementById('status-text');
    const domainTextElement = document.getElementById('domain-text');

    // Fetch the lists from our JSON file first.
    let siteLists = {};
    try {
        const url = chrome.runtime.getURL('site_lists.json');
        const response = await fetch(url);
        siteLists = await response.json();
    } catch (error) {
        statusTextElement.textContent = "Error loading lists.";
        console.error("Error loading site lists:", error);
        return;
    }

    // Get the current active tab in the browser.
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentTab = tabs[0];
        if (!currentTab || !currentTab.url) {
            statusTextElement.textContent = "Cannot access URL.";
            return;
        }

        const url = new URL(currentTab.url);
        const domain = url.hostname; // e.g., "www.coinbase.com"

        domainTextElement.textContent = domain; // Display the domain name.

        // Check the domain against our lists.
        const isSiteMalicious = siteLists.maliciousSites.some(maliciousSite => domain.includes(maliciousSite));
        const isSiteSafe = siteLists.safeSites.some(safeSite => domain.includes(safeSite));

        if (isSiteMalicious) {
            statusTextElement.textContent = "This website is in unsafe DATABASE LIST - EXIT NOW";
            statusTextElement.style.color = "red";
        } else if (isSiteSafe) {
            statusTextElement.textContent = "This website is Safe and verified!";
            statusTextElement.style.color = "green";
        } else {
            statusTextElement.textContent = "Unknown Site -this website is not related to CRYPTO projects";
            statusTextElement.style.color = "orange";
        }
    });
});