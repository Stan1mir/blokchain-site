﻿//  list of pre-approved, safe crypto websites.
const safeSites = [
    'coinbase.com',
    'uniswap.org',
    'metamask.io',
    'binance.com',
    'kraken.com'
];

// NEW: Our list of known malicious websites.
// For testing, we will use a harmless example site.
const maliciousSites = [
    'example.com' // We will use example.com as our test "malicious" site.
];

// This function checks the URL and updates the icon.
function updateIcon(tabId, url) {
    if (!url) {
        return; // Exit if the URL is not available
    }

    // NEW: Check for malicious sites FIRST.
    const isSiteMalicious = maliciousSites.some(maliciousSite => url.includes(maliciousSite));

    // Check for safe sites.
    const isSiteSafe = safeSites.some(safeSite => url.includes(safeSite));

    let iconPath;
    if (isSiteMalicious) {
        // If a site is malicious, use the 'default.png' (red) icon.
        iconPath = 'icons/icon-safe.png';
    } else if (isSiteSafe) {
        // If a site is safe, use the 'safe.png' (green) icon.
        iconPath = 'icons/icon-default.png';
    } else {
        // For all other unknown sites, use the new 'orange.png' icon.
        iconPath = 'icons/orange.png';
    }

    // Set the icon for the specific tab
    chrome.action.setIcon({
        path: { "128": iconPath },
        tabId: tabId
    });
}

// --- The rest of the code is the same ---

// This event runs when a tab is updated (e.g., new page loads).
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        updateIcon(tabId, tab.url);
    }
});

// This event runs when the user switches to a different tab.
chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        if (tab && tab.url) {
            updateIcon(tab.id, tab.url);
        }
    });
});